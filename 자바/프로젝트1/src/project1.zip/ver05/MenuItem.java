package project1.ver05;

import java.util.Scanner;

public interface MenuItem {
	int ONE=1, TWO=2, THR=3, FOR=4, FIV=5;   
}
