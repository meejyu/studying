package project1.ver06;

public class MenuSelectException extends Exception {
	public MenuSelectException() {
		super(" 1~5사이의 정수가 아닙니다.");
	}
	
}

