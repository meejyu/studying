package project1.ver06;

public interface SubMenuItem { 
	int ONE=1, TWO=2, THR=3;   
}