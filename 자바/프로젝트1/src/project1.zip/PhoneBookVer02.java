package project1;

import java.util.Scanner;

import project1.ver02.PhoneInfo;

public class PhoneBookVer02 {

	public static void main(String[] args) {
		PhoneInfo phoneInfo1 = new PhoneInfo();
		phoneInfo1.showPhoneInfo();
	}
}
