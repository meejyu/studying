package project1.ver07;

public interface SubMenuItem { 
	int ONE=1, TWO=2, THR=3;   
}